package com.example.flutter_ea2_arm_240625

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
